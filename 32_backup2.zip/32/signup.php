<h2>Регистрация нового пользователя</h2>
<form method="POST" action="signUpCheck.php">
    <input type="text" name="login" placeholder="Введите ник">
    <input type="password" name="password" placeholder="Пароль">
    <button>Зарегистрироваться</button>
</form>