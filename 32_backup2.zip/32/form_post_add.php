<form method="POST" action="post_add.php" enctype="multipart/form-data">
    <p>Заголовок поста:</p>
	<input type="text" name="post_title" placeholder="Заголовок поста">
	<p>Текст поста:</p>
	<textarea type="text" name="post_text" placeholder="Текст поста" style="height:500px"></textarea>
	<p>Изображение поста:</p>
	<input type="file" name="post_img" placeholder="Загрузка картинки">
	<button>Добавить пост</button>
</form>