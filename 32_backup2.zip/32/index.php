<!DOCTYPE html>
<html>
<head>
	<title>Главная страница</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
		html{
			height:100%;

		}
		body{
			height:100%;
			background: rgb(2,0,36);
			background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,9,121,1) 35%, rgba(0,212,255,1) 100%);
		}
		
		.title{
			font-family:Arial;
			font-size:90px
		}
	</style>
</head>
<body class="text-light bg-dark" style="background-attachment:fixed">
<?php 
	session_start();
	$con = mysqli_connect("j06932379.myjino.ru", "j06932379", "2gsEZtqt5R", "j06932379"); 

	if(isset($_SESSION['user_id'])) {
		$select = "SELECT * FROM users WHERE id = {$_SESSION['user_id']}";
		$query = mysqli_query($con, $select);
		$select_user = mysqli_fetch_assoc($query);

		echo "Привет! " . $select_user['login'];
		echo "<a href='form_post_add.php'> Создать пост </a>";
		echo "<a href='logout.php'> Выйти</a>";
	} else {
?>
<a href="signup.php" >Регистрация</a>
<a href="login.php">Войти</a>

<?php 
	}
?>
				<h1>Главная страница</h1>
<?php 
					$get_all_posts_query = "SELECT * FROM posts INNER JOIN users ON posts.user_id = users.id ORDER BY posts.post_id DESC";
					$posts_results = mysqli_query($con, $get_all_posts_query); 
				?>
				<?php 
					for($i = 0; $i < mysqli_num_rows($posts_results); $i++) {
							$post = mysqli_fetch_assoc($posts_results);
				?>	

			<!--один пост-->
			<div class="col-4 p-3 text-dark mt-2" >
			<div class="col-12 bg-light rounded p-3" >
				<img src="<?php echo $post['image']; ?>" class="rounded w-75">
				<div>
				    <h3><?php echo $post['post_title']; ?></h3>
					<p style="word-wrap: break-word;"><?php echo $post['text']; ?></p>
					<p><?php echo "Автор: " . $post['login']; ?></p>
					
					<?php if(isset($_SESSION['user_id'])) { ?>
					    <form method="POST" action="updateProject.php" class="text-center">
									<input type="text" name="post_id" placeholder="id" class="form-control mt-2" value="<?php echo $post['post_id']; ?>" style="display: none;">
									<textarea type="text" name="comment" placeholder="Текст комментария..." class="form-control mt-2" value="<?php echo $post['text']; ?>"></textarea>
									<button class="btn btn-success mt-2">Оставить комментарий</button>	
						</form>
					<?php } ?>
				
				</div>
			</div>
		</div>	
<?php } ?>

</body>
</html>

<script type="text/javascript">
	let btnUpdate = document.querySelectorAll(".updateBtn");
	let form = document.querySelectorAll(".updateForm");
	let showEdit = 0;

	for(let i = 0; i < btnUpdate.length; i++) {
		btnUpdate[i].onclick = function() {
		    if(showEdit == 0) {
			    form[i].style.display = "block";
			    showEdit = 1;
		    } else {
		        form[i].style.display = "none";
		        showEdit = 0;
		    }
		}
	}
</script>