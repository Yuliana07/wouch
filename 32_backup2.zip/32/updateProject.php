<?php 
    session_start();

	$uploaded_file_path = "img/" . basename($_FILES['post_img']['name']);
	$source_file = $_FILES['post_img']['tmp_name']; 
	$upload = move_uploaded_file($source_file, $uploaded_file_path);
	
    $connection_to_database = mysqli_connect("j06932379.myjino.ru", "j06932379", "2gsEZtqt5R", "j06932379"); 
    
    if($source_file != null) {
        $update = "UPDATE posts SET text = '{$_POST["text"]}', post_title = '{$_POST["post_title"]}', image = '{$uploaded_file_path}' WHERE post_id = {$_POST["post_id"]}";
    } else {
        $update = "UPDATE posts SET text = '{$_POST["text"]}', post_title = '{$_POST["post_title"]}' WHERE post_id = {$_POST["post_id"]}";
    }
    $results = mysqli_query($connection_to_database, $update);
    header("Location: index.php");
    exit;
?>