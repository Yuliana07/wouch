<?php 
	session_start();
	$con = mysqli_connect("j06932379.myjino.ru", "j06932379", "2gsEZtqt5R", "j06932379"); 
	$query_text = "INSERT INTO users (login, password) VALUES ('{$_POST['login']}', '{$_POST['password']}')";
	$results = mysqli_query($con, $query_text); 

	$_SESSION['user_id'] = mysqli_insert_id($con);
	header("Location: index.php");
?>
