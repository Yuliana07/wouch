<h2>Авторизация пользователя</h2>
<form method="POST" action="login_check.php">
    <input type="text" name="login" placeholder="Введите ник">
    <input type="password" name="password" placeholder="Пароль">
    <button>Войти</button>
</form>