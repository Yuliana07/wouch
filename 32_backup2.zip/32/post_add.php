<?php 
	session_start();

	$uploaded_file_path = "img/" . basename($_FILES['post_img']['name']);
	$source_file = $_FILES['post_img']['tmp_name']; 
	$upload = move_uploaded_file($source_file, $uploaded_file_path);

	$con = mysqli_connect("j06932379.myjino.ru", "j06932379", "2gsEZtqt5R", "j06932379"); 
	$query_text = "INSERT INTO posts (post_title, text, image, user_id) VALUES ('{$_POST['post_title']}', '{$_POST['post_text']}', '{$uploaded_file_path}', '{$_SESSION['user_id']}')";
	$query = mysqli_query($con, $query_text);

	header("Location: index.php");	
?>