<?php 
    $connection_to_database =  mysqli_connect("j06932379.myjino.ru", "j06932379", "2gsEZtqt5R", "j06932379"); 
    $delete = "DELETE FROM posts WHERE post_id = {$_GET['post_id']} ";
    $query = mysqli_query($connection_to_database, $delete);
    header("Location: index.php");
    exit;
?>